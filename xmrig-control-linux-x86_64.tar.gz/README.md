# XMRig

[![Github All Releases](https://img.shields.io/github/downloads/xmrig/xmrig/total.svg)](https://github.com/xmrig/xmrig/releases)
[![GitHub release](https://img.shields.io/github/release/xmrig/xmrig/all.svg)](https://github.com/xmrig/xmrig/releases)
[![GitHub Release Date](https://img.shields.io/github/release-date/xmrig/xmrig.svg)](https://github.com/xmrig/xmrig/releases)
[![GitHub license](https://img.shields.io/github/license/xmrig/xmrig.svg)](https://github.com/xmrig/xmrig/blob/master/LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/xmrig/xmrig.svg)](https://github.com/xmrig/xmrig/stargazers)
[![GitHub forks](https://img.shields.io/github/forks/xmrig/xmrig.svg)](https://github.com/xmrig/xmrig/network)

XMRig is a high performance, open source, cross platform RandomX, KawPow, CryptoNight and [GhostRider](https://github.com/xmrig/xmrig/tree/master/src/crypto/ghostrider#readme) unified CPU/GPU miner and [RandomX benchmark](https://xmrig.com/benchmark). Official binaries are available for Windows, Linux, macOS and FreeBSD.

## Mining backends
- **CPU** (x86/x64/ARMv7/ARMv8/RISC-V)
- **OpenCL** for AMD GPUs.
- **CUDA** for NVIDIA GPUs via external [CUDA plugin](https://github.com/xmrig/xmrig-cuda).

## Download
* **[Binary releases](https://github.com/xmrig/xmrig/releases)**
* **[Build from source](https://xmrig.com/docs/miner/build)**

## Usage
The preferred way to configure the miner is the [JSON config file](https://xmrig.com/docs/miner/config) as it is more flexible and human friendly. The [command line interface](https://xmrig.com/docs/miner/command-line-options) does not cover all features, such as mining profiles for different algorithms. Important options can be changed during runtime without miner restart by editing the config file or executing [API](https://xmrig.com/docs/miner/api) calls.

* **[Wizard](https://xmrig.com/wizard)** helps you create initial configuration for the miner.
* **[Workers](http://workers.xmrig.info)** helps manage your miners via HTTP API.

## Configuração utilizada neste build
* **Algoritmo: [RandomX](https://github.com/xmrig/xmrig/tree/master/doc)** (otimizado para CPU, `rx/0` para Monero) — verifique no log do miner a linha `cpu` com o perfil ativo e o aviso `use profile ... rx/0`.
* **Pool: [MoneroOcean](https://moneroocean.stream/)** — pool multi-moeda com auto-troca de algoritmo. Exemplo de configuração:

  ```json
  "pools": [
      {
          "url": "gulf.moneroocean.stream:10128",
          "user": "SUA_CARTEIRA_XMR",
          "pass": "x",
          "tls": false
      }
  ]
  ```

* Site do pool: **https://moneroocean.stream/**

### Como monitorar os resultados
1. **Dashboard do pool**: acesse https://moneroocean.stream/, cole sua carteira XMR no campo de busca e veja hashrate, trabalhadores (workers), blocos encontrados e saldo/pagamentos em tempo real.
2. **Console do miner**:
   - `accepted (X/Y) diff N` = shares aceitos/rejeitados pelo pool.
   - `new job from ... diff ... algo rx/0` = jobs chegando normalmente do pool.
   - `h` no console = histórico de doações do desenvolvedor desta build.
   - `s` no console = estatísticas de resultados; `c` = estado da conexão.
3. **API HTTP local**: com `"http-enabled": true` e `"http-port": 8080` na config, monitore via `curl http://127.0.0.1:8080/2/summary` (hashrate, resultados, conexão) ou abra a interface em `http://IP:8080`.
4. **Log em arquivo**: adicione `"log-file": "xmrig.log"` na config para guardar todo o histórico (shares aceitos/rejeitados, doações, erros de conexão).

## Donations
* Default donation 1% (1 minute in 100 minutes) can be increased via option `donate-level` or disabled in source code.
* XMR: `88axy8H9ZNwZnQuFU4kfNWX7eXFm6o9uH7Nnb9zXZgL58RUeownTv73aJnAYCf1DNJBAHCVPiFQYC2qizizquMH91rdw8MP`

## Developers
* **[xmrig](https://github.com/xmrig)**
* **[sech1](https://github.com/SChernykh)**

## Contacts
* support@xmrig.com
* [reddit](https://www.reddit.com/user/XMRig/)
* [twitter](https://twitter.com/xmrig_dev)
