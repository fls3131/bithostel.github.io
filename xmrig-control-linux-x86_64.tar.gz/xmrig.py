#!/usr/bin/env python3

import os
import queue
import re
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.request
import urllib.error
import webbrowser
import json
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk


DONATE_LEVEL = 5  # percentual da sua capacidade de mineracao doado ao desenvolvedor (--donate-level)
DONATE_WALLET = "88axy8H9ZNwZnQuFU4kfNWX7eXFm6o9uH7Nnb9zXZgL58RUeownTv73aJnAYCf1DNJBAHCVPiFQYC2qizizquMH91rdw8MP"  # carteira que recebe a doacao
DONATE_CYCLE = 100 // DONATE_LEVEL  # minutos de mineracao propria entre cada 1 minuto de doacao
DONATE_INFO = (  # explicacao para o usuario
    "Sobre a doacao ao desenvolvedor:\n\n"
    f"• Percentual: {DONATE_LEVEL}% da sua capacidade de mineracao (opcao --donate-level).\n"
    f"• Na pratica: o minerador minera para o desenvolvedor cerca de {DONATE_LEVEL} minuto(s) a cada {DONATE_CYCLE} minuto(s).\n"
    f"• A primeira doacao acontece entre {int(DONATE_CYCLE * 0.5)} e {int(DONATE_CYCLE * 1.5)} minutos apos o inicio (agenda aleatoria do XMRig).\n"
    f"• Carteira que recebe a doacao: {DONATE_WALLET}\n"
    "• Durante a doacao o log mostra “(DEV DONATE)” nos jobs e “dev donation started/finished”.\n\n"
    "As doacoes da sessao (tempo total e shares aceitas/rejeitadas) aparecem no cartao DOACAO DO DEV e ficam gravadas no Historico."
)
ALGORITHM = "rx/0"  # algoritmo fixo desta build: RandomX (Monero)
POOL_URL = "https://moneroocean.stream/"  # dashboard do pool para monitorar resultados
APP_NAME = "XMRig Control"
APP_VERSION = "1.2.0"
APP_LICENSE = "GPL v3"
MINER_BINARY = "build/xmrig"
LICENSE_FILE_URL = "https://www.gnu.org/licenses/gpl-3.0.html"
DONATE_STARTED_RE = re.compile(r"dev donate started", re.IGNORECASE)
DONATE_FINISHED_RE = re.compile(r"dev donate finished", re.IGNORECASE)


def format_duration(seconds):
    minutes, seconds = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def format_donation(entry):
    donated_time = entry.get("donated_time")
    if donated_time is None:
        return "-"
    return f"{format_duration(donated_time)} ({entry.get('donated_accepted', 0)}/{entry.get('donated_rejected', 0)})"


def format_hash_total(value):
    return f"{value:,}".replace(",", ".")


def history_hash_total(entry, key):
    try:
        return int(entry.get(key, 0) or 0)
    except (TypeError, ValueError):
        return 0


POOL_OPTIONS = [
    ("gulf.moneroocean.stream:80 | 1 kH/s | plain", "gulf.moneroocean.stream:80", False),
    ("gulf.moneroocean.stream:443 | 1 kH/s | TLS", "gulf.moneroocean.stream:443", True),
    ("gulf.moneroocean.stream:10001 | 1 KH/s | plain", "gulf.moneroocean.stream:10001", False),
    ("gulf.moneroocean.stream:10002 | 2 KH/s | plain", "gulf.moneroocean.stream:10002", False),
    ("gulf.moneroocean.stream:10004 | 4 KH/s | plain", "gulf.moneroocean.stream:10004", False),
    ("gulf.moneroocean.stream:10008 | 8 KH/s | plain", "gulf.moneroocean.stream:10008", False),
    ("gulf.moneroocean.stream:10016 | 16 KH/s | plain", "gulf.moneroocean.stream:10016", False),
    ("gulf.moneroocean.stream:10032 | 32 KH/s | plain", "gulf.moneroocean.stream:10032", False),
    ("gulf.moneroocean.stream:10064 | 64 KH/s | plain", "gulf.moneroocean.stream:10064", False),
    ("gulf.moneroocean.stream:10128 | 128 KH/s | plain", "gulf.moneroocean.stream:10128", False),
    ("gulf.moneroocean.stream:10256 | 256 KH/s | plain", "gulf.moneroocean.stream:10256", False),
    ("gulf.moneroocean.stream:10512 | 512 KH/s | plain", "gulf.moneroocean.stream:10512", False),
    ("gulf.moneroocean.stream:11024 | 1 MH/s | plain", "gulf.moneroocean.stream:11024", False),
    ("gulf.moneroocean.stream:12048 | 2 MH/s | plain", "gulf.moneroocean.stream:12048", False),
    ("gulf.moneroocean.stream:14096 | 4 MH/s | plain", "gulf.moneroocean.stream:14096", False),
    ("gulf.moneroocean.stream:18192 | 8 MH/s | plain", "gulf.moneroocean.stream:18192", False),
    ("gulf.moneroocean.stream:20001 | 1 KH/s | TLS", "gulf.moneroocean.stream:20001", True),
    ("gulf.moneroocean.stream:20002 | 2 KH/s | TLS", "gulf.moneroocean.stream:20002", True),
    ("gulf.moneroocean.stream:20004 | 4 KH/s | TLS", "gulf.moneroocean.stream:20004", True),
    ("gulf.moneroocean.stream:20008 | 8 KH/s | TLS", "gulf.moneroocean.stream:20008", True),
    ("gulf.moneroocean.stream:20016 | 16 KH/s | TLS", "gulf.moneroocean.stream:20016", True),
    ("gulf.moneroocean.stream:20032 | 32 KH/s | TLS", "gulf.moneroocean.stream:20032", True),
    ("gulf.moneroocean.stream:20064 | 64 KH/s | TLS", "gulf.moneroocean.stream:20064", True),
    ("gulf.moneroocean.stream:20128 | 128 KH/s | TLS", "gulf.moneroocean.stream:20128", True),
    ("gulf.moneroocean.stream:20256 | 256 KH/s | TLS", "gulf.moneroocean.stream:20256", True),
    ("gulf.moneroocean.stream:20512 | 512 KH/s | TLS", "gulf.moneroocean.stream:20512", True),
    ("gulf.moneroocean.stream:21024 | 1 MH/s | TLS", "gulf.moneroocean.stream:21024", True),
    ("gulf.moneroocean.stream:22048 | 2 MH/s | TLS", "gulf.moneroocean.stream:22048", True),
    ("gulf.moneroocean.stream:24096 | 4 MH/s | TLS", "gulf.moneroocean.stream:24096", True),
    ("gulf.moneroocean.stream:28192 | 8 MH/s | TLS", "gulf.moneroocean.stream:28192", True),
]


def pool_difficulty_group(label):
    match = re.search(r"\|\s*([0-9]+)\s*(KH/s|kH/s|MH/s)", label)
    if not match:
        return "Dificuldade desconhecida"
    value = int(match.group(1))
    if match.group(2).lower() == "mh/s":
        value *= 1024
    if value <= 8:
        return "Baixa Dificuldade"
    if value <= 128:
        return "Média Dificuldade"
    return "Alta Dificuldade"


def pool_display_label(option):
    return f"{option[0]} | {pool_difficulty_group(option[0])}"


class XmrigGui(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("XMRig Control")
        self.geometry("900x680")
        self.minsize(720, 560)
        self.configure(bg="#101820")

        self.project_root = Path(__file__).resolve().parent.parent
        self.binary = Path("/usr/local/xmrig-control") / "xmrig"
        self.settings_file = Path.home() / ".config" / "xmrig-gui" / "settings.json"
        self.history_file = Path.home() / ".config" / "xmrig-gui" / "history.json"
        self.process = None
        self.history_entry = None
        self.output_queue = queue.Queue()
        self.api_port = 18080
        self.api_stop = threading.Event()
        self.api_error_reported = False
        self.thread_count = os.cpu_count() or 1
        self.accepted_hashes = 0
        self.rejected_hashes = 0
        self.mining_started_at = None
        self.donate_started_at = None
        self.donate_snapshot = None
        self.donated_seconds = 0.0
        self.donated_accepted = 0
        self.donated_rejected = 0

        self.wallet = tk.StringVar()
        self.pool = tk.StringVar(value="gulf.moneroocean.stream:10128")
        self.pool_selection = tk.StringVar()
        self.threads = tk.IntVar(value=self.thread_count)
        self.status = tk.StringVar(value="Pronto para iniciar")
        self.connection = tk.StringVar(value="OFFLINE")
        self.current_speed = tk.StringVar(value="0 H/s")
        self.average_speed = tk.StringVar(value="0 H/s")
        self.accepted = tk.StringVar(value="0")
        self.rejected = tk.StringVar(value="0")
        self.donation_display = tk.StringVar(value="00:00:00 (0/0) • 0,0% da sessão")
        self.cpu_display = tk.StringVar(value="0% total • 0% miner")
        self.cpu_total_prev = None   # (total, idle) de /proc/stat no último ciclo
        self.cpu_proc_prev = None    # (cpu_time, monotonic) do processo do miner
        self.clock = tk.StringVar(value="--:--:--")
        self.mining_time = tk.StringVar(value="00:00:00")
        self.speed_pattern = re.compile(r"speed\s+10s/60s/15m\s+([0-9.]+)\s+([0-9.]+|n/a)")
        self.accepted_pattern = re.compile(r"accepted(?:\s+\((\d+)\/\d+\))?", re.IGNORECASE)
        self.rejected_pattern = re.compile(r"rejected(?:\s+\((\d+)\/\d+\))?", re.IGNORECASE)

        self._load_settings()
        self._build_form()
        self._update_clock()
        self.after(100, self._drain_output)
        self.protocol("WM_DELETE_WINDOW", self._close)

    def _build_form(self):
        self.style = ttk.Style(self)
        self.style.theme_use("clam")
        self.style.configure("TButton", font=("TkDefaultFont", 10, "bold"), padding=(14, 8))
        self.style.configure("Accent.TButton", foreground="#ffffff", background="#19a974")
        self.style.map("Accent.TButton", background=[("active", "#168f62")])
        self.style.configure("TEntry", padding=8)
        self.style.configure("TSpinbox", padding=6)
        self.style.configure("Compact.TButton", font=("TkDefaultFont", 9), padding=(8, 4))
        self._build_menu()

        frame = tk.Frame(self, bg="#101820", padx=28, pady=24)
        frame.pack(fill="both", expand=True)
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(5, weight=1)

        header = tk.Frame(frame, bg="#101820")
        header.grid(row=0, column=0, sticky="ew", pady=(0, 20))
        tk.Label(header, text="XMRig", font=("TkDefaultFont", 26, "bold"), fg="#f4f7f9", bg="#101820").pack(anchor="w")
        algo_frame = tk.Frame(header, bg="#101820")
        algo_frame.pack(anchor="w", pady=(4, 0))
        tk.Label(algo_frame, text="ALGORITMO", font=("TkDefaultFont", 8, "bold"), fg="#9aabb5", bg="#101820").pack(side="left", padx=(0, 6))
        tk.Label(algo_frame, text="RandomX (rx/0)", font=("TkDefaultFont", 11, "bold"), fg="#7ed6b2", bg="#101820").pack(side="left", padx=(0, 12))
        tk.Label(algo_frame, text="POOL", font=("TkDefaultFont", 8, "bold"), fg="#9aabb5", bg="#101820").pack(side="left", padx=(0, 6))
        pool_link = tk.Label(algo_frame, text="MoneroOcean", font=("TkDefaultFont", 11, "bold", "underline"), fg="#7ed6b2", bg="#101820", cursor="hand2")
        pool_link.pack(side="left")
        pool_link.bind("<Button-1>", lambda _e: webbrowser.open(POOL_URL))
        tk.Label(header, text="Painel de mineração", font=("TkDefaultFont", 11), fg="#9aabb5", bg="#101820").pack(anchor="w", pady=(2, 0))
        info = tk.Frame(header, bg="#101820")
        info.pack(anchor="e", pady=(0, 2))
        tk.Label(info, text="HORA", font=("TkDefaultFont", 8, "bold"), fg="#7ed6b2", bg="#101820").pack(side="left", padx=(0, 6))
        tk.Label(info, textvariable=self.clock, font=("TkDefaultFont", 12, "bold"), fg="#f4f7f9", bg="#101820").pack(side="left", padx=(0, 18))
        tk.Label(info, text="MINERAÇÃO", font=("TkDefaultFont", 8, "bold"), fg="#7ed6b2", bg="#101820").pack(side="left", padx=(0, 6))
        tk.Label(info, textvariable=self.mining_time, font=("TkDefaultFont", 12, "bold"), fg="#f2c879", bg="#101820").pack(side="left")

        config = tk.Frame(frame, bg="#1b2932", padx=18, pady=14)
        config.grid(row=1, column=0, sticky="ew", pady=(0, 16))
        config.columnconfigure(1, weight=1)
        tk.Label(config, text="CONFIGURAÇÃO", font=("TkDefaultFont", 9, "bold"), fg="#7ed6b2", bg="#1b2932").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        tk.Label(config, text="Carteira Monero", fg="#dbe5e9", bg="#1b2932").grid(row=1, column=0, sticky="w", padx=(0, 14), pady=5)
        wallet_entry = ttk.Entry(config, textvariable=self.wallet)
        wallet_entry.grid(row=1, column=1, sticky="ew", pady=5)
        wallet_entry.focus_set()
        wallet_buttons = tk.Frame(config, bg="#1b2932")
        wallet_buttons.grid(row=1, column=2, sticky="w", padx=(8, 0), pady=5)
        self.copy_button = ttk.Button(wallet_buttons, text="Copiar", style="Compact.TButton", width=9, command=self._copy_wallet)
        self.copy_button.pack(side="left", padx=(0, 6))
        self.paste_button = ttk.Button(wallet_buttons, text="Colar", style="Compact.TButton", width=8, command=self._paste_wallet)
        self.paste_button.pack(side="left")
        for wallet_button in (self.copy_button, self.paste_button):
            wallet_button._flash_original = wallet_button.cget("text")
            wallet_button._flash_job = None
        tk.Label(config, text="Pool", fg="#dbe5e9", bg="#1b2932").grid(row=2, column=0, sticky="w", padx=(0, 14), pady=5)
        self.pool_selector = ttk.Combobox(config, textvariable=self.pool_selection, values=[pool_display_label(option) for option in POOL_OPTIONS], state="readonly")
        self.pool_selector.grid(row=2, column=1, sticky="ew", pady=5)
        self.pool_selector.bind("<<ComboboxSelected>>", self._select_pool)
        tk.Label(config, text="Threads", fg="#dbe5e9", bg="#1b2932").grid(row=3, column=0, sticky="w", padx=(0, 14), pady=5)
        ttk.Spinbox(config, from_=1, to=self.thread_count, textvariable=self.threads, width=8).grid(row=3, column=1, sticky="w", pady=5)
        tk.Label(config, text=f"detectadas: {self.thread_count}", fg="#9aabb5", bg="#1b2932").grid(row=3, column=1, sticky="w", padx=(100, 0), pady=5)

        controls = tk.Frame(frame, bg="#101820")
        controls.grid(row=2, column=0, sticky="ew", pady=(0, 16))
        self.start_button = ttk.Button(controls, text="Iniciar mineração", style="Accent.TButton", command=self._start)
        self.start_button.pack(side="left", padx=(0, 8))
        self.stop_button = ttk.Button(controls, text="Parar", command=self._stop, state="disabled")
        self.stop_button.pack(side="left")
        self.pool_link_button = ttk.Button(controls, text="MoneroOcean", style="Compact.TButton", command=lambda: webbrowser.open(POOL_URL))
        self.pool_link_button.pack(side="left", padx=(8, 0))
        self.history_button = ttk.Button(controls, text="Histórico", style="Compact.TButton", command=self._show_history)
        self.history_button.pack(side="left", padx=(8, 0))
        self.status_label = tk.Label(controls, textvariable=self.status, fg="#9aabb5", bg="#101820", font=("TkDefaultFont", 9))
        self.status_label.pack(side="right", pady=8)

        stats = tk.Frame(frame, bg="#101820")
        stats.grid(row=3, column=0, sticky="ew", pady=(0, 16))
        for column in range(3):
            stats.columnconfigure(column, weight=1)
        self._stat_card(stats, 0, "VELOCIDADE ATUAL", self.current_speed, "H/s", "#6ed6ad")
        self._stat_card(stats, 1, "MÉDIA (60s)", self.average_speed, "H/s", "#75b9ed")
        self._stat_card(stats, 2, "HASHES ACEITAS", self.accepted, "shares", "#f2c879")
        self._stat_card(stats, 3, "HASHES REJEITADAS", self.rejected, "shares", "#e98b8b")
        self._donation_card(stats, 4)
        self._cpu_card(stats, 5)
        for column in range(6):
            stats.columnconfigure(column, weight=1)

        footer = tk.Frame(frame, bg="#101820")
        footer.grid(row=4, column=0, sticky="ew", pady=(0, 10))
        footer_info = f"{APP_NAME} v{APP_VERSION}  \u2022  licen\u00e7a: {APP_LICENSE}  \u2022  XMRig 6.26.0  \u2022  algoritmo: RandomX (rx/0)  \u2022  pool: MoneroOcean  \u2022  doa\u00e7\u00e3o ao dev: {DONATE_LEVEL}%"
        tk.Label(footer, text=footer_info, font=("TkDefaultFont", 8), fg="#9aabb5", bg="#101820").pack(side="left")
        lic_link = tk.Label(footer, text="GNU GPL v3", font=("TkDefaultFont", 8, "underline"), fg="#75b9ed", bg="#101820", cursor="hand2")
        lic_link.pack(side="right")
        lic_link.bind("<Button-1>", lambda _e: webbrowser.open(LICENSE_FILE_URL))

        log_frame = tk.Frame(frame, bg="#1b2932", padx=12, pady=10)
        log_frame.grid(row=5, column=0, sticky="nsew")
        log_frame.rowconfigure(1, weight=1)
        log_frame.columnconfigure(0, weight=1)
        log_header = tk.Frame(log_frame, bg="#1b2932")
        log_header.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        tk.Label(log_header, text="LOG DO MINERADOR", font=("TkDefaultFont", 9, "bold"), fg="#7ed6b2", bg="#1b2932").pack(side="left")
        tk.Label(log_header, textvariable=self.connection, font=("TkDefaultFont", 9, "bold"), fg="#f2c879", bg="#1b2932").pack(side="right")
        self.output = tk.Text(log_frame, wrap="none", state="disabled", height=12, bg="#0d1419", fg="#b9c7cd", insertbackground="#ffffff", relief="flat", padx=10, pady=8)
        self.output.grid(row=1, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.output.yview)
        scrollbar.grid(row=1, column=1, sticky="ns")
        self.output.configure(yscrollcommand=scrollbar.set)
        self.pool_selection.set(next((pool_display_label(option) for option in POOL_OPTIONS if option[1] == self.pool.get()), pool_display_label(POOL_OPTIONS[9])))

    def _select_pool(self, _event=None):
        selected = self.pool_selection.get()
        for label, endpoint, _tls in POOL_OPTIONS:
            if selected == pool_display_label((label, endpoint, _tls)):
                self.pool.set(endpoint)
                return

    def _copy_wallet(self):
        wallet = self.wallet.get().strip()
        if not wallet:
            messagebox.showinfo("Copiar carteira", "O campo carteira está vazio.")
            return
        self.clipboard_clear()
        self.clipboard_append(wallet)
        self.update()
        self._flash_button(self.copy_button, "Copiado!")

    def _paste_wallet(self):
        try:
            clipboard = self.clipboard_get().strip()
        except tk.TclError:
            clipboard = ""
        if not clipboard:
            messagebox.showwarning("Colar carteira", "A área de transferência está vazia ou não contém texto.")
            return
        self.wallet.set(clipboard)
        self._flash_button(self.paste_button, "Colado!")

    def _flash_button(self, button, feedback):
        if button._flash_job is not None:
            self.after_cancel(button._flash_job)
        button.configure(text=feedback)
        button._flash_job = self.after(1200, lambda: button.configure(text=button._flash_original))

    def _set_status(self, text, highlighted=False):
        self.status.set(text)
        if highlighted:
            self.status_label.configure(bg="#17342a", fg="#7ed6b2", font=("TkDefaultFont", 10, "bold"), padx=10, pady=3)
        else:
            self.status_label.configure(bg="#101820", fg="#9aabb5", font=("TkDefaultFont", 9), padx=0, pady=0)

    def _build_menu(self):
        menu_bar = tk.Menu(self)
        help_menu = tk.Menu(menu_bar, tearoff=False)
        help_menu.add_command(label="Como usar", command=self._show_help)
        help_menu.add_command(label="Sobre a doação (dev donate)", command=lambda: messagebox.showinfo("Doação ao desenvolvedor", DONATE_INFO))
        help_menu.add_command(label="Sobre o XMRig Control", command=self._show_about)
        help_menu.add_separator()
        monero_help_menu = tk.Menu(help_menu, tearoff=False)
        monero_help_menu.add_command(label="O que é Monero", command=lambda: self._open_monero_help("https://www.getmonero.org/get-started/what-is-monero/"))
        monero_help_menu.add_command(label="Downloads oficiais", command=lambda: self._open_monero_help("https://www.getmonero.org/downloads/"))
        monero_help_menu.add_command(label="Perguntas frequentes (FAQ)", command=lambda: self._open_monero_help("https://www.getmonero.org/get-started/faq/"))
        monero_help_menu.add_command(label="Guias de usuário", command=lambda: self._open_monero_help("https://www.getmonero.org/resources/user-guides/"))
        monero_help_menu.add_command(label="Moneropedia", command=lambda: self._open_monero_help("https://www.getmonero.org/resources/moneropedia/"))
        monero_help_menu.add_command(label="Mineração", command=lambda: self._open_monero_help("https://www.getmonero.org/resources/moneropedia/mining.html"))
        monero_help_menu.add_command(label="Comunidade", command=lambda: self._open_monero_help("https://www.getmonero.org/community/hangouts/"))
        help_menu.add_cascade(label="Ajuda do Monero", menu=monero_help_menu)
        help_menu.add_separator()
        help_menu.add_command(label="Histórico de minerações", command=self._show_history)
        help_menu.add_command(label="Salvar configuração", command=self._save_settings_with_feedback)
        help_menu.add_command(label="Limpar configuração salva", command=self._clear_settings)
        menu_bar.add_cascade(label="Menu", menu=help_menu)
        self.configure(menu=menu_bar)

    def _open_monero_help(self, url):
        try:
            browser_script = Path(__file__).with_name("xmrig_browser.py")
            subprocess.Popen([sys.executable, str(browser_script), url], cwd=self.project_root)
        except OSError:
            if not webbrowser.open(url):
                messagebox.showerror("Não foi possível abrir o navegador", "Instale PyQt5 com QtWebEngine ou um navegador externo.")

    def _load_settings(self):
        try:
            with self.settings_file.open(encoding="utf-8") as settings_file:
                settings = json.load(settings_file)
            self.wallet.set(str(settings.get("wallet", "")))
            self.pool.set(str(settings.get("pool", self.pool.get())))
            saved_threads = int(settings.get("threads", self.thread_count))
            self.threads.set(max(1, min(saved_threads, self.thread_count)))
        except (OSError, ValueError, TypeError):
            self.threads.set(self.thread_count)
        self.pool_selection.set(next((pool_display_label(option) for option in POOL_OPTIONS if option[1] == self.pool.get()), pool_display_label(POOL_OPTIONS[9])))

    def _save_settings(self):
        try:
            threads = int(self.threads.get())
        except (TypeError, ValueError):
            threads = self.thread_count
        settings = {
            "wallet": self.wallet.get().strip(),
            "pool": self.pool.get().strip(),
            "threads": max(1, min(threads, self.thread_count)),
        }
        try:
            self.settings_file.parent.mkdir(parents=True, exist_ok=True)
            with self.settings_file.open("w", encoding="utf-8") as settings_file:
                json.dump(settings, settings_file, indent=2)
        except (OSError, ValueError, TypeError):
            self._append_output("[GUI] Não foi possível salvar a configuração.\n")

    def _save_settings_with_feedback(self):
        self._save_settings()
        messagebox.showinfo("Configuração salva", f"Dados salvos em:\n{self.settings_file}")

    def _clear_settings(self):
        try:
            self.settings_file.unlink(missing_ok=True)
            self.wallet.set("")
            self.pool.set("gulf.moneroocean.stream:10128")
            self.pool_selection.set(pool_display_label(POOL_OPTIONS[9]))
            self.threads.set(self.thread_count)
            messagebox.showinfo("Configuração limpa", "Os dados salvos foram removidos.")
        except OSError as error:
            messagebox.showerror("Erro", f"Não foi possível limpar a configuração:\n{error}")

    def _load_history(self):
        try:
            with self.history_file.open(encoding="utf-8") as history_file:
                history = json.load(history_file)
            return history if isinstance(history, list) else []
        except (OSError, ValueError, TypeError):
            return []

    def _save_history(self, history):
        try:
            self.history_file.parent.mkdir(parents=True, exist_ok=True)
            with self.history_file.open("w", encoding="utf-8") as history_file:
                json.dump(history[-100:], history_file, indent=2, ensure_ascii=False)
        except (OSError, ValueError, TypeError):
            self._append_output("[GUI] Não foi possível salvar o histórico.\n")

    def _record_history(self, status, elapsed=None):
        if self.history_entry is None:
            return
        self._finish_donate_round()
        entry = dict(self.history_entry)
        entry.update({
            "status": status,
            "duration": elapsed if elapsed is not None else 0,
            "accepted": self.accepted_hashes,
            "rejected": self.rejected_hashes,
            "donated_time": int(self.donated_seconds),
            "donated_accepted": self.donated_accepted,
            "donated_rejected": self.donated_rejected,
        })
        history = self._load_history()
        history.append(entry)
        self._save_history(history)
        self.history_entry = None

    def _show_history(self):
        history_window = tk.Toplevel(self)
        history_window.title("Histórico de minerações")
        history_window.geometry("960x420")
        history_window.minsize(820, 300)
        history_window.configure(bg="#101820")
        history_window.transient(self)

        container = tk.Frame(history_window, bg="#101820", padx=18, pady=18)
        container.pack(fill="both", expand=True)
        container.rowconfigure(0, weight=1)
        container.columnconfigure(0, weight=1)
        columns = ("started", "pool", "threads", "duration", "donated", "accepted", "rejected", "status")
        table = ttk.Treeview(container, columns=columns, show="headings")
        headings = {
            "started": "Início",
            "pool": "Pool",
            "threads": "Threads",
            "duration": "Duração",
            "donated": "Doação",
            "accepted": "Aceitas",
            "rejected": "Rejeitadas",
            "status": "Status",
        }
        widths = {"started": 145, "pool": 180, "threads": 70, "duration": 90, "donated": 150, "accepted": 70, "rejected": 80, "status": 100}
        for column in columns:
            table.heading(column, text=headings[column])
            table.column(column, width=widths[column], anchor="center")
        table.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=table.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        table.configure(yscrollcommand=scrollbar.set)

        history_entries = self._load_history()
        total_accepted = sum(history_hash_total(entry, "accepted") for entry in history_entries)
        total_rejected = sum(history_hash_total(entry, "rejected") for entry in history_entries)

        for entry in reversed(history_entries):
            table.insert("", "end", values=(
                entry.get("started", "-"), entry.get("pool", "-"), entry.get("threads", "-"),
                format_duration(entry.get("duration", 0)), format_donation(entry),
                entry.get("accepted", 0), entry.get("rejected", 0), entry.get("status", "-"),
            ))

        totals = tk.Frame(container, bg="#101820")
        totals.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        for column in range(3):
            totals.columnconfigure(column, weight=1)
        total_labels = {
            "executions": self._history_total_chip(totals, 0, "EXECUÇÕES", str(len(history_entries)), "#f4f7f9"),
            "accepted": self._history_total_chip(totals, 1, "TOTAL HASHES ACEITAS", format_hash_total(total_accepted), "#f2c879"),
            "rejected": self._history_total_chip(totals, 2, "TOTAL HASHES REJEITADAS", format_hash_total(total_rejected), "#e98b8b"),
        }

        buttons = tk.Frame(container, bg="#101820")
        buttons.grid(row=2, column=0, columnspan=2, sticky="e", pady=(12, 0))

        def clear_history():
            if not messagebox.askyesno("Limpar histórico", "Remover todo o histórico de minerações?", parent=history_window):
                return
            self._save_history([])
            for item in table.get_children():
                table.delete(item)
            for label in total_labels.values():
                label.configure(text="0")

        ttk.Label(buttons, text="Doação: tempo e shares (aceitas/rejeitadas) processados nas rodadas de doação do desenvolvedor.", foreground="#9aabb5").pack(side="left", padx=(0, 12))
        ttk.Button(buttons, text="Limpar histórico", command=clear_history).pack(side="left", padx=(0, 8))
        ttk.Button(buttons, text="Fechar", command=history_window.destroy).pack(side="left")

    def _show_help(self):
        messagebox.showinfo(
            "Como usar",
            "1. Informe a carteira Monero (use os botões Copiar/Colar ao lado do campo, se precisar).\n"
            "2. Confira a pool e escolha a quantidade de threads.\n"
            "3. Clique em Iniciar mineração.\n\n"
            "A velocidade, média e shares são lidas pela API local do XMRig.\n"
            "As configurações são salvas automaticamente ao iniciar e ao fechar.\n\n"
            f"Doação ao desenvolvedor: {DONATE_LEVEL}% da sua capacidade — {DONATE_LEVEL} minuto(s) "
            f"mineração para o dev a cada {DONATE_CYCLE} minuto(s).\n"
            "Acompanhe no cartão DOAÇÃO DO DEV e no Histórico. Detalhes no menu "
            '> “Sobre a doação (dev donate)”.',
        )

    def _show_about(self):
        messagebox.showinfo(
            f"Sobre o {APP_NAME}",
            f"{APP_NAME} v{APP_VERSION}\n"
            "Interface gráfica local para o XMRig.\n\n"
            "Minerador: XMRig 6.26.0 (binário compilado em build/xmrig)\n"
            "Algoritmo: RandomX (rx/0) \u2022 Pool: MoneroOcean (moneroocean.stream)\n"
            "API local: usada apenas para exibir métricas.\n\n"
            f"Doação ao desenvolvedor: {DONATE_LEVEL}% da capacidade de mineração "
            f"({DONATE_LEVEL} minuto(s) mineração para o dev a cada {DONATE_CYCLE} minuto(s)).\n"
            f"Carteira da doação: {DONATE_WALLET}\n\n"
            f"Versão da GUI: {APP_VERSION}\n"
            f"Licença: {APP_LICENSE} (GNU General Public License versão 3)\n"
            f"Texto completo da licença: {LICENSE_FILE_URL}\n"
            "Este programa é distribuído sem garantia; consulte a GPL v3 para detalhes.",
        )
    def _stat_card(self, parent, column, title, variable, suffix, color):
        card = tk.Frame(parent, bg="#1b2932", padx=16, pady=12)
        card.grid(row=0, column=column, sticky="ew", padx=(0 if column == 0 else 6, 6 if column < 2 else 0))
        tk.Label(card, text=title, font=("TkDefaultFont", 8, "bold"), fg="#9aabb5", bg="#1b2932").pack(anchor="w")
        value_row = tk.Frame(card, bg="#1b2932")
        value_row.pack(anchor="w", pady=(5, 0))
        tk.Label(value_row, textvariable=variable, font=("TkDefaultFont", 20, "bold"), fg=color, bg="#1b2932").pack(side="left")
        tk.Label(value_row, text=suffix, font=("TkDefaultFont", 9), fg="#9aabb5", bg="#1b2932").pack(side="left", padx=(6, 0), pady=(8, 0))

    def _cpu_card(self, parent, column):
        card = tk.Frame(parent, bg="#1b2932", padx=16, pady=12)
        card.grid(row=0, column=column, sticky="ew", padx=(0, 6))
        tk.Label(card, text="USO DE CPU", font=("TkDefaultFont", 8, "bold"), fg="#9aabb5", bg="#1b2932").pack(anchor="w")
        tk.Label(card, textvariable=self.cpu_display, font=("TkDefaultFont", 13, "bold"), fg="#7ec8e3", bg="#1b2932").pack(anchor="w", pady=(5, 0))
        tk.Label(card, text=f"sistema • processo do miner ({self.thread_count} núcleos)", font=("TkDefaultFont", 8), fg="#9aabb5", bg="#1b2932").pack(anchor="w")

    def _read_cpu_times(self):
        # Tempo total e ocioso de /proc/stat (soma de todas as CPUs).
        try:
            with open("/proc/stat") as f:
                parts = f.readline().split()[1:]
            values = [int(x) for x in parts]
            idle = values[3] + (values[4] if len(values) > 4 else 0)  # idle + iowait
            return sum(values), idle
        except (OSError, ValueError, IndexError):
            return None

    def _read_proc_cpu_time(self):
        # Tempo de CPU (utime+stime, em segundos) consumido pelo processo do miner.
        pid = self.process.pid if self.process is not None else None
        if pid is None:
            return None
        try:
            with open(f"/proc/{pid}/stat") as f:
                fields = f.read().rsplit(")", 1)[1].split()
            ticks = int(fields[11]) + int(fields[12])
            return ticks / os.sysconf("SC_CLK_TCK")
        except (OSError, ValueError, IndexError, AttributeError):
            return None

    def _sample_cpu(self):
        # Chamado a cada segundo: calcula o uso de CPU do sistema e do miner no último intervalo.
        sample = self._read_cpu_times()
        proc_cpu = self._read_proc_cpu_time()
        now = time.monotonic()

        if sample is None:
            self.cpu_display.set("n/d (sistema sem /proc/stat)")
            return

        if self.cpu_total_prev is not None:
            total_delta = sample[0] - self.cpu_total_prev[0]
            idle_delta = sample[1] - self.cpu_total_prev[1]
            total_percent = 100.0 * (1.0 - idle_delta / total_delta) if total_delta > 0 else 0.0
        else:
            total_percent = 0.0
        self.cpu_total_prev = sample

        proc_percent = 0.0
        if proc_cpu is not None and self.cpu_proc_prev is not None:
            elapsed = now - self.cpu_proc_prev[1]
            if elapsed > 0:
                # % do total da máquina (não de um único núcleo).
                proc_percent = min(100.0, 100.0 * (proc_cpu - self.cpu_proc_prev[0]) / (elapsed * max(1, self.thread_count)))
        self.cpu_proc_prev = (proc_cpu, now) if proc_cpu is not None else None

        self.cpu_display.set(f"{total_percent:.0f}% total • {proc_percent:.0f}% miner")

    def _donation_card(self, parent, column):
        card = tk.Frame(parent, bg="#1b2932", padx=16, pady=12)
        card.grid(row=0, column=column, sticky="ew", padx=(0, 6))
        header = tk.Frame(card, bg="#1b2932")
        header.pack(anchor="w")
        tk.Label(header, text="DOAÇÃO DO DEV", font=("TkDefaultFont", 8, "bold"), fg="#9aabb5", bg="#1b2932").pack(side="left")
        info_link = tk.Label(header, text="  (o que é isto?)", font=("TkDefaultFont", 8, "underline"), fg="#75b9ed", bg="#1b2932", cursor="hand2")
        info_link.pack(side="left")
        info_link.bind("<Button-1>", lambda _e: messagebox.showinfo("Doação ao desenvolvedor", DONATE_INFO))
        tk.Label(card, textvariable=self.donation_display, font=("TkDefaultFont", 13, "bold"), fg="#c8a2f0", bg="#1b2932").pack(anchor="w", pady=(5, 0))
        tk.Label(card, text=f"{DONATE_LEVEL}% da capacidade • tempo (aceitas/rejeitadas)", font=("TkDefaultFont", 8), fg="#9aabb5", bg="#1b2932").pack(anchor="w")

    def _history_total_chip(self, parent, column, title, value, color):
        card = tk.Frame(parent, bg="#1b2932", padx=16, pady=10)
        card.grid(row=0, column=column, sticky="ew", padx=(0 if column == 0 else 6, 6 if column < 2 else 0))
        tk.Label(card, text=title, font=("TkDefaultFont", 8, "bold"), fg="#9aabb5", bg="#1b2932").pack(anchor="w")
        value_label = tk.Label(card, text=value, font=("TkDefaultFont", 16, "bold"), fg=color, bg="#1b2932")
        value_label.pack(anchor="w", pady=(3, 0))
        return value_label

    def _start(self):
        if self.process is not None:
            return
        wallet = self.wallet.get().strip()
        pool = self.pool.get().strip()
        try:
            threads = int(self.threads.get())
        except (TypeError, ValueError):
            threads = 0
        if not wallet:
            messagebox.showerror("Carteira obrigatória", "Informe uma carteira Monero.")
            return
        if not pool or threads < 1 or threads > self.thread_count:
            messagebox.showerror("Configuração inválida", f"Use uma pool e entre 1 e {self.thread_count} threads.")
            return
        if not self.binary.is_file():
            messagebox.showerror("Binário não encontrado", f"Compile o XMRig antes de iniciar:\n{self.binary}")
            return

        self._save_settings()
        selected_tls = next((tls for _label, endpoint, tls in POOL_OPTIONS if endpoint == pool), False)
        command = [str(self.binary), "-o", pool, "-u", wallet, "-p", "x", "-a", ALGORITHM, f"--donate-level={DONATE_LEVEL}", "--threads", str(threads), "--print-time=10", "--no-color", "--http-host=127.0.0.1", f"--http-port={self.api_port}"]
        if selected_tls:
            command.append("--tls")
        self._append_output("$ " + " ".join(command) + "\n")
        try:
            self.process = subprocess.Popen(command, cwd=self.project_root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        except OSError as error:
            self.process = None
            messagebox.showerror("Falha ao iniciar", str(error))
            return
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self._set_status(f"Executando com {threads} threads", highlighted=True)
        self.mining_started_at = time.monotonic()
        self.donate_started_at = None
        self.donate_snapshot = None
        self.donated_seconds = 0.0
        self.donated_accepted = 0
        self.donated_rejected = 0
        self.cpu_total_prev = None
        self.cpu_proc_prev = None
        self.history_entry = {
            "started": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "pool": pool,
            "threads": threads,
            "donate_level": DONATE_LEVEL,
        }
        self.mining_time.set("00:00:00")
        self.connection.set("CONECTANDO")
        self.accepted_hashes = 0
        self.rejected_hashes = 0
        self.accepted.set("0")
        self.rejected.set("0")
        self.current_speed.set("0 H/s")
        self.average_speed.set("0 H/s")
        self.api_error_reported = False
        self.api_stop.clear()
        threading.Thread(target=self._read_output, args=(self.process,), daemon=True).start()
        threading.Thread(target=self._read_api, daemon=True).start()

    def _read_output(self, process):
        for line in process.stdout:
            self.output_queue.put(line)
        process.wait()
        self.output_queue.put(("__finished__", process.returncode))

    def _read_api(self):
        url = f"http://127.0.0.1:{self.api_port}/1/summary"
        while not self.api_stop.wait(1):
            try:
                with urllib.request.urlopen(url, timeout=1) as response:
                    data = json.load(response)
                self.output_queue.put(("__metrics__", data))
            except (OSError, ValueError, urllib.error.HTTPError) as error:
                if not self.api_error_reported and self.process is not None:
                    self.api_error_reported = True
                    self.output_queue.put(("__api_error__", str(error)))
                continue

    def _drain_output(self):
        try:
            while True:
                item = self.output_queue.get_nowait()
                if isinstance(item, tuple) and item[0] == "__finished__":
                    self.api_stop.set()
                    if self.mining_started_at is not None:
                        elapsed = int(time.monotonic() - self.mining_started_at)
                        hours, remainder = divmod(elapsed, 3600)
                        minutes, seconds = divmod(remainder, 60)
                        self.mining_time.set(f"{hours:02d}:{minutes:02d}:{seconds:02d}")
                        self._record_history("encerrada", elapsed)
                    self.mining_started_at = None
                    self.process = None
                    self.start_button.configure(state="normal")
                    self.stop_button.configure(state="disabled")
                    self._set_status(f"Processo encerrado (código {item[1]})")
                    self.connection.set("OFFLINE")
                elif isinstance(item, tuple) and item[0] == "__metrics__":
                    self._update_api_metrics(item[1])
                elif isinstance(item, tuple) and item[0] == "__api_error__":
                    self._append_output(f"[GUI] API HTTP indisponível: {item[1]}\n")
                else:
                    self._update_metrics(item)
                    self._append_output(item)
        except queue.Empty:
            pass
        self.after(100, self._drain_output)

    def _update_clock(self):
        self.clock.set(datetime.now().strftime("%H:%M:%S"))
        self._sample_cpu()
        if self.mining_started_at is not None and self.process is not None:
            elapsed = int(time.monotonic() - self.mining_started_at)
            hours, remainder = divmod(elapsed, 3600)
            minutes, seconds = divmod(remainder, 60)
            self.mining_time.set(f"{hours:02d}:{minutes:02d}:{seconds:02d}")
            live_percent = min(100.0, self.donated_seconds * 100.0 / elapsed) if elapsed > 0 else 0.0
            self.donation_display.set(
                f"{format_duration(self.donated_seconds)} "
                f"({self.donated_accepted}/{self.donated_rejected}) "
                f"• {live_percent:.1f}% da sessão"
            )
        self.after(1000, self._update_clock)

    def _update_api_metrics(self, data):
        hashrate = data.get("hashrate", {}).get("total", [])
        results = data.get("results", {})
        if len(hashrate) >= 2 and all(isinstance(value, (int, float)) for value in hashrate[:2]):
            self.current_speed.set(f"{hashrate[0]:.1f} H/s")
            self.average_speed.set(f"{hashrate[1]:.1f} H/s")
        self.accepted_hashes = int(results.get("shares_good", self.accepted_hashes))
        self.rejected_hashes = int(results.get("shares_bad", self.rejected_hashes))
        self.accepted.set(str(self.accepted_hashes))
        self.rejected.set(str(self.rejected_hashes))
        self.connection.set("CONECTADO")

    def _update_metrics(self, line):
        speed_match = self.speed_pattern.search(line)
        if speed_match:
            self.current_speed.set(f"{speed_match.group(1)} H/s")
            average = speed_match.group(2)
            self.average_speed.set(f"{average if average != 'n/a' else '0'} H/s")
        if "use pool" in line or "new job" in line:
            self.connection.set("CONECTADO")
        accepted_match = self.accepted_pattern.search(line)
        rejected_match = self.rejected_pattern.search(line)
        if accepted_match:
            self.accepted_hashes = int(accepted_match.group(1) or self.accepted_hashes + 1)
            self.accepted.set(str(self.accepted_hashes))
        if rejected_match:
            self.rejected_hashes = int(rejected_match.group(1) or self.rejected_hashes + 1)
            self.rejected.set(str(self.rejected_hashes))
        if DONATE_STARTED_RE.search(line):
            self.donate_started_at = time.monotonic()
            self.donate_snapshot = (self.accepted_hashes, self.rejected_hashes)
        elif DONATE_FINISHED_RE.search(line):
            self._finish_donate_round()

    def _finish_donate_round(self):
        if self.donate_started_at is None:
            return
        self.donated_seconds += max(0.0, time.monotonic() - self.donate_started_at)
        accepted, rejected = self.donate_snapshot if self.donate_snapshot else (self.accepted_hashes, self.rejected_hashes)
        self.donated_accepted += max(0, self.accepted_hashes - accepted)
        self.donated_rejected += max(0, self.rejected_hashes - rejected)
        self.donate_started_at = None
        self.donate_snapshot = None

    def _append_output(self, text):
        self.output.configure(state="normal")
        self.output.insert("end", text)
        self.output.see("end")
        self.output.configure(state="disabled")

    def _stop(self):
        if self.process is not None:
            self.api_stop.set()
            self.process.terminate()
            self._set_status("Parando...")
            self.connection.set("ENCERRANDO")

    def _close(self):
        self._save_settings()
        if self.process is not None:
            self.api_stop.set()
            elapsed = int(time.monotonic() - self.mining_started_at) if self.mining_started_at is not None else 0
            self._record_history("interrompida", elapsed)
            self.process.terminate()
            self.process.wait(timeout=3)
        self.destroy()


if __name__ == "__main__":
    XmrigGui().mainloop()
