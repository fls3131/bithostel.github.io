#!/usr/bin/env bash
# =============================================================================
# XMRig Control — Instalador universal para Linux (x86_64)
# Distribuicoes suportadas:
#   DEB : Debian, Ubuntu, MX Linux, Mint, Pop!_OS            (apt-get)
#   RPM : Fedora, RHEL, CentOS, Rocky, Alma                   (dnf/yum)
#   SUSE: openSUSE Leap/Tumbleweed                            (zypper)
#   ARCH: Arch, Manjaro, EndeavourOS                          (pacman)
#   OUTRAS: Alpine (apk), Solus (eopkg); sem gerenciador conhecido,
#           prossegue se as dependencias ja estiverem presentes.
# Instala o minerador (binário RandomX) + GUI e cria entradas no menu.
# Uso:  sudo ./install-linux.sh            (instalação no sistema: /opt + atalhos)
#       ./install-linux.sh --user          (instalação apenas para o usuário atual)
#       ./install-linux.sh --uninstall     (remove a instalação)
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
APP_NAME="XMRig Control"
INSTALL_SYSTEM_DIR="/usr/local/xmrig-control"
INSTALL_USER_DIR="$HOME/.local/share/xmrig-control"
BIN_DIR_SYSTEM="/usr/local/bin"
BIN_DIR_USER="$HOME/.local/bin"
DESKTOP_SYSTEM="/usr/share/applications"
DESKTOP_USER="$HOME/.local/share/applications"
ICON_NAME="xmrig-control.png"

MODE=""
UNINSTALL=0
for arg in "$@"; do
    case "$arg" in
        --user)      MODE="user" ;;
        --uninstall) UNINSTALL=1 ;;
        -h|--help)
            echo "Uso: ./install-linux.sh [--user] [--uninstall]"
            echo "  (padrão)       instala no sistema (requer sudo/root)"
            echo "  --user         instala apenas para o usuário atual (sem root)"
            echo "  --uninstall    remove a instalação (detecta modo automaticamente)"
            exit 0
            ;;
        *) echo "Argumento desconhecido: $arg" >&2; exit 1 ;;
    esac
done

info()  { printf '\033[1;36m==\033[0m %s\n' "$*"; }
error() { printf '\033[1;31mERRO:\033[0m %s\n' "$*" >&2; exit 1; }

if [ "$UNINSTALL" = "1" ]; then
    if [ -d "$INSTALL_SYSTEM_DIR" ] && [ -w "$INSTALL_SYSTEM_DIR" ] || [ "$(id -u)" = "0" ]; then
        info "Removendo instalação do sistema..."
        rm -rf "$INSTALL_SYSTEM_DIR"
        rm -f "$BIN_DIR_SYSTEM/xmrig-control" "$DESKTOP_SYSTEM/xmrig-control.desktop" "$DESKTOP_SYSTEM/$ICON_NAME" 2>/dev/null || true
    fi
    if [ -d "$INSTALL_USER_DIR" ]; then
        info "Removendo instalação do usuário..."
        rm -rf "$INSTALL_USER_DIR"
        rm -f "$BIN_DIR_USER/xmrig-control" "$DESKTOP_USER/xmrig-control.desktop" "$DESKTOP_USER/$ICON_NAME" 2>/dev/null || true
    fi
    info "Desinstalação concluída."
    exit 0
fi

if [ -z "$MODE" ]; then
    if [ "$(id -u)" = "0" ]; then MODE="system"; else MODE="user"; fi
fi

if [ "$MODE" = "system" ] && [ "$(id -u)" != "0" ]; then
    error "Instalação no sistema requer root. Use: sudo $0  (ou $0 --user)"
fi

if [ "$MODE" = "system" ]; then
    INSTALL_DIR="$INSTALL_SYSTEM_DIR"; BIN_DIR="$BIN_DIR_SYSTEM"; DESKTOP_DIR="$DESKTOP_SYSTEM"
else
    INSTALL_DIR="$INSTALL_USER_DIR";  BIN_DIR="$BIN_DIR_USER";  DESKTOP_DIR="$DESKTOP_USER"
    mkdir -p "$BIN_DIR_USER" "$HOME/.local/share/applications"
fi

# ---------------------------------------------------------------- dependências
SUDO=""
if [ "$(id -u)" != "0" ]; then
    if command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi
fi

DISTRO_ID="unknown"; DISTRO_NAME="desconhecida"; DISTRO_LIKE=""
if [ -r /etc/os-release ]; then
    . /etc/os-release 2>/dev/null || true
    DISTRO_ID="${ID:-unknown}"
    DISTRO_LIKE="${ID_LIKE:-}"
    DISTRO_NAME="${PRETTY_NAME:-$DISTRO_ID}"
fi
info "Distribuicao: $DISTRO_NAME"

PKGMGR=""; PKGINST=""
if   command -v apt-get >/dev/null 2>&1; then PKGMGR="apt";    PKGINST="apt-get install -y"
elif command -v dnf     >/dev/null 2>&1; then PKGMGR="dnf";    PKGINST="dnf install -y"
elif command -v yum     >/dev/null 2>&1; then PKGMGR="yum";    PKGINST="yum install -y"
elif command -v zypper  >/dev/null 2>&1; then PKGMGR="zypper"; PKGINST="zypper install -y"
elif command -v pacman  >/dev/null 2>&1; then PKGMGR="pacman"; PKGINST="pacman -Sy --noconfirm"
elif command -v microdnf >/dev/null 2>&1; then PKGMGR="dnf";   PKGINST="microdnf install -y"
elif command -v apk     >/dev/null 2>&1; then PKGMGR="apk";    PKGINST="apk add"
elif command -v eopkg   >/dev/null 2>&1; then PKGMGR="eopkg";  PKGINST="eopkg install -y"
fi
info "Gerenciador de pacotes: ${PKGMGR:-desconhecido (seguira sem instalacao automatica)}"
PY=python3

MISSING_PKGS=""
check_bin() {  # check_bin <comando> <pacote-apt> <pacote-dnf> <pacote-pacman> <pacote-zypper>
    local cmd="$1" pkg_apt="$2" pkg_dnf="$3" pkg_pac="$4" pkg_zy="$5"
    if command -v "$cmd" >/dev/null 2>&1; then
        info "  [ok] $cmd"
    else
        info "  [faltando] $cmd (pacote: ${pkg_apt})"
        case "$PKGMGR" in
            apt)    MISSING_PKGS="$MISSING_PKGS $pkg_apt" ;;
            dnf)    MISSING_PKGS="$MISSING_PKGS $pkg_dnf" ;;
            yum)    MISSING_PKGS="$MISSING_PKGS $pkg_dnf" ;;
            pacman) MISSING_PKGS="$MISSING_PKGS $pkg_pac" ;;
            zypper) MISSING_PKGS="$MISSING_PKGS $pkg_zy" ;;
            apk)    MISSING_PKGS="$MISSING_PKGS $pkg_apt" ;;
            eopkg)  MISSING_PKGS="$MISSING_PKGS $pkg_dnf" ;;
        esac
    fi
}

info "Verificando dependências..."
check_bin python3  python3        python3        python        python3
check_bin curl     curl           curl           curl          curl
check_bin tar      tar            tar            tar           tar
check_bin openssl  openssl        openssl        openssl       openssl

TK_OK=1
"$PY" - <<'PYCHK' 2>/dev/null || TK_OK=0
import tkinter
PYCHK
if [ "$TK_OK" = "0" ]; then
    info "  [faltando] tkinter (módulo Python)"
    case "$PKGMGR" in
        apt)    MISSING_PKGS="$MISSING_PKGS python3-tk" ;;
        dnf)    MISSING_PKGS="$MISSING_PKGS python3-tkinter" ;;
        yum)    MISSING_PKGS="$MISSING_PKGS tkinter" ;;
        pacman) MISSING_PKGS="$MISSING_PKGS tk" ;;
        zypper) MISSING_PKGS="$MISSING_PKGS python3-tk" ;;
        apk)    MISSING_PKGS="$MISSING_PKGS python3-tkinter" ;;
        eopkg)  MISSING_PKGS="$MISSING_PKGS python3-tkinter" ;;
    esac
else
    info "  [ok] tkinter"
fi

if [ -n "$MISSING_PKGS" ]; then
    info "Instalando dependências ausentes:$MISSING_PKGS"
    [ -n "$SUDO" ] || error "Dependências ausentes mas sem permissão de root para instalá-las. Rode: sudo $0"
    case "$PKGMGR" in
        apt)
            $SUDO apt-get update -y
            $SUDO apt-get install -y $MISSING_PKGS || error "Falha ao instalar:$MISSING_PKGS. Instale manualmente e rode novamente."
            ;;
        dnf)    $SUDO $PKGINST $MISSING_PKGS || error "Falha ao instalar:$MISSING_PKGS (dnf/microdnf)" ;;
        yum)    $SUDO $PKGINST $MISSING_PKGS || error "Falha ao instalar:$MISSING_PKGS (yum)" ;;
        zypper) $SUDO zypper --non-interactive install $MISSING_PKGS || error "Falha ao instalar:$MISSING_PKGS (zypper)" ;;
        pacman) $SUDO pacman -Sy --noconfirm $MISSING_PKGS || error "Falha ao instalar:$MISSING_PKGS (pacman)" ;;
        apk)    $SUDO apk add $MISSING_PKGS || error "Falha ao instalar:$MISSING_PKGS (apk)" ;;
        eopkg)  $SUDO eopkg install -y $MISSING_PKGS || error "Falha ao instalar:$MISSING_PKGS (eopkg)" ;;
        *) error "Gerenciador de pacotes ($PKGMGR) não suportado na distribuicao '$DISTRO_ID'. Instale manualmente:$MISSING_PKGS" ;;
    esac
else
    info "Todas as dependências já estão presentes."
fi

command -v "$PY" >/dev/null 2>&1 || error "python3 continua ausente após a instalação."
"$PY" -c 'import tkinter' 2>/dev/null || error "tkinter continua ausente após a instalação (verifique python3-tk)."

# Localiza o binário na raiz atual, no PROJECT_ROOT ou na pasta build
XMRIG_BIN=""
if [ -f "./xmrig" ]; then
    XMRIG_BIN="./xmrig"
elif [ -f "$PROJECT_ROOT/xmrig" ]; then
    XMRIG_BIN="$PROJECT_ROOT/xmrig"
elif [ -f "$PROJECT_ROOT/build/xmrig" ]; then
    XMRIG_BIN="$PROJECT_ROOT/build/xmrig"
fi

if [ -n "$XMRIG_BIN" ]; then
    MISSING_LIBS=$(ldd "$XMRIG_BIN" 2>/dev/null || true)
    info "Bibliotecas do binário xmrig verificadas."
fi

# -------------------------------------------------------------- arquivos
info "Instalando em: $INSTALL_DIR"
mkdir -p "$INSTALL_DIR" "$BIN_DIR" "$DESKTOP_DIR"

if [ -n "$XMRIG_BIN" ]; then
    install -m 0755 "$XMRIG_BIN" "$INSTALL_DIR/xmrig"
else
    error "Binário 'xmrig' não encontrado. Certifique-se de que ele está na raiz do projeto ou na pasta build."
fi

if [ -f "$PROJECT_ROOT/scripts/xmrig_gui.py" ]; then
    install -m 0644 "$PROJECT_ROOT/scripts/xmrig_gui.py" "$INSTALL_DIR/xmrig_gui.py"
elif [ -f "./xmrig_gui.py" ]; then
    install -m 0644 "./xmrig_gui.py" "$INSTALL_DIR/xmrig_gui.py"
else
    error "Arquivo 'xmrig_gui.py' não encontrado."
fi

for doc in LICENSE README.md; do
    [ -f "$PROJECT_ROOT/$doc" ] && install -m 0644 "$PROJECT_ROOT/$doc" "$INSTALL_DIR/$doc"
done

# ------------------------------------------------------------------ launcher
install -m 0755 /dev/stdin "$BIN_DIR/xmrig-control" <<LAUNCHER
#!/usr/bin/env bash
# XMRig Control launcher
exec "$PY" "$INSTALL_DIR/xmrig.py" "\$@"
LAUNCHER

if [ -f "$PROJECT_ROOT/scripts/xmrig_gui.py" ]; then
    cp -f "$PROJECT_ROOT/scripts/xmrig_gui.py" "$INSTALL_DIR/xmrig.py"
else
    cp -f "./xmrig_gui.py" "$INSTALL_DIR/xmrig.py"
fi

sed -i "s#self.binary = self.project_root / \"build\" / \"xmrig\"#self.binary = Path(\"$INSTALL_DIR\") / \"xmrig\"#" \
    "$INSTALL_DIR/xmrig.py"

# ---------------------------------------------------------------------- ícone
ICON="$PROJECT_ROOT/scripts/$ICON_NAME"
[ ! -f "$ICON" ] && ICON="./$ICON_NAME"
if [ -f "$ICON" ]; then
    install -m 0644 "$ICON" "$DESKTOP_DIR/$ICON_NAME"
    ICON_LINE="Icon=$DESKTOP_DIR/$ICON_NAME"
else
    ICON_LINE="Icon=applications-system"
fi

# --------------------------------------------------------------- atalho .desktop
install -m 0644 /dev/stdin "$DESKTOP_DIR/xmrig-control.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Version=1.0
Name=$APP_NAME
GenericName=Minerador XMRig (RandomX)
Comment=Painel de mineração MoneroOcean — RandomX (rx/0)
Exec=$BIN_DIR/xmrig-control
TryExec=$BIN_DIR/xmrig-control
$ICON_LINE
Terminal=false
Categories=Network;
Keywords=xmrig;monero;mining;randomx;
DESKTOP

DESKTOP_ENV="${XDG_CURRENT_DESKTOP:-unknown}"
WM_DETECTED=""
if pgrep -x gnome-shell >/dev/null 2>&1; then WM_DETECTED="GNOME Shell"
elif pgrep -x plasmashell >/dev/null 2>&1; then WM_DETECTED="KDE Plasma"
elif pgrep -x kwin_x11 >/dev/null 2>&1 || pgrep -x kwin_wayland >/dev/null 2>&1; then WM_DETECTED="KWin"
elif pgrep -x xfce4-session >/dev/null 2>&1; then WM_DETECTED="xfwm4"
elif pgrep -x cinnamon >/dev/null 2>&1; then WM_DETECTED="Cinnamon (Muffin)"
elif pgrep -x mate-session >/dev/null 2>&1; then WM_DETECTED="MATE (Marco)"
elif pgrep -x lxsession >/dev/null 2>&1; then WM_DETECTED="LXDE (Openbox)"
elif pgrep -x lxqt-session >/dev/null 2>&1; then WM_DETECTED="LXQt"
elif pgrep -x icewm >/dev/null 2>&1; then WM_DETECTED="IceWM"
elif pgrep -x openbox >/dev/null 2>&1; then WM_DETECTED="Openbox"
elif pgrep -x fluxbox >/dev/null 2>&1; then WM_DETECTED="Fluxbox"
elif pgrep -x jwm >/dev/null 2>&1; then WM_DETECTED="JWM"
fi

info "Ambiente gráfico detectado: ${DESKTOP_ENV}${WM_DETECTED:+ ($WM_DETECTED)}"

case "$DESKTOP_ENV" in
    *KDE*|*Plasma*)
        if command -v kbuildsycoca5 >/dev/null 2>&1; then
            kbuildsycoca5 --noincremental 2>/dev/null || true
        elif command -v kbuildsycoca6 >/dev/null 2>&1; then
            kbuildsycoca6 --noincremental 2>/dev/null || true
        elif command -v kbuildsycoca >/dev/null 2>&1; then
            kbuildsycoca --noincremental 2>/dev/null || true
        fi
        ;;
    *GNOME*)
        command -v xdg-desktop-menu >/dev/null 2>&1 && \
            xdg-desktop-menu install --novendor "$DESKTOP_DIR/xmrig-control.desktop" 2>/dev/null || true
        ;;
    *)
        ;;
esac

if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$DESKTOP_DIR" 2>/dev/null || true
fi
if command -v xdg-desktop-menu >/dev/null 2>&1; then
    xdg-desktop-menu forceupdate 2>/dev/null || true
fi

[ "$MODE" = "user" ] && mkdir -p "$HOME/.local/share/applications"

info "Instalação concluída!"
echo "  • Ambiente:  ${DESKTOP_ENV:-desconhecido}${WM_DETECTED:+ ($WM_DETECTED)} — atalho adicionado ao menu"
echo "  • Launcher:  $BIN_DIR/xmrig-control"
echo "  • App:       $INSTALL_DIR"
echo "  • Atalho:    menu de aplicativos → '$APP_NAME'"
echo "  • Para executar agora:  xmrig-control   (ou: $BIN_DIR/xmrig-control)"
echo "  • Para remover:          $0 --uninstall"
